import requests
from datetime import datetime
import os
import urllib.request
from bs4 import BeautifulSoup
def function(link):
    lst=[]
    newlst=[]
    try:
        status=requests.get(link)
        if status.status_code == 200:
            parser=BeautifulSoup(status.content,"html.parser")
            a_tags=parser.find_all('a')
            flag=0
            for x in a_tags:
                href=x['href']
                if href.endswith(".mp3"):
                    lst.append(link+x['href'])
                    flag=1

            if flag==1:
                start=len(lst)-26
                end=len(lst)
                if start<0:
                    start=0

                for i in range(start,end):
                    newlst.append(lst[i])
        
        return newlst
            
    except:
        print("Mp3 link error") 
        return []

def main():
    URL="https://download.quranicaudio.com/quran/"
    qari_link=[]
    qari_name=[]
    try:
        status=requests.get(URL)
        if status.status_code == 200:
            parser=BeautifulSoup(status.content,"html.parser")
            a_tags=parser.find_all('a')
            for a in a_tags:
                qari_link.append(URL+a['href'])
                qari_name.append(a.text)
            
            qari_link.pop()
            qari_name.pop()
            qari_name.remove("../")
            qari_link.remove("https://download.quranicaudio.com/quran/../")

            #now = datetime.now()
            log_file= open("log.txt","w+")
            log_file.write(str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")) + " Total Qari : " + str(len(qari_link))+"\n")
            
            for i in range(0,len(qari_link)):
                log_file.write(str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")) +" Strat Processing "+ str(i+1)+" out of "+ str(len(qari_link))+"\n")
                log_file.write(str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")) +" Qari Name : "+str(qari_name[i])+"\n")
                
                links=function(qari_link[i])
                
                if len(links)>0:
                    os.mkdir(qari_name[i])
                    os.chdir(qari_name[i])
                    for j in links:
                        name=j.rsplit('/',1)[-1]
                        log_file.write(str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")) + " " +str(qari_name[i])+" "+str(name)+" Start \n")
                        urllib.request.urlretrieve(j,name)
                        log_file.write(str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")) + " " + str(qari_name[i])+" "+str(name)+" End \n")
                    
                    #merge
                    log_file.write(str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")) + " Merging the Files of "+ str(qari_name[i])+" Start \n" )
                    os.system("copy /b *.mp3 out.mp3")
                    #os.system("mp3wrap out.mp3 *.mp3")
                    log_file.write(str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")) + " Merging the Files of "+ str(qari_name[i])+" End \n" )
                    log_file.write("\n \n")
                    os.chdir("../")
                break
            log_file.close()

    except:
        print("main Error !")

if __name__=="__main__":
    main()
